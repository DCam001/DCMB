Grove IO Images for use with tutorial
